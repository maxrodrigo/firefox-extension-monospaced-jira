# Monospace Jira

**This add-on convert inputs input-like fields in Jira to Monospace.**

# Contribute

```
1. git clone git@github.com:maxrodrigo/webext-monospaced-jira.git
1. make build
1. Load the plugin into Firefox
```

Happy coding!
